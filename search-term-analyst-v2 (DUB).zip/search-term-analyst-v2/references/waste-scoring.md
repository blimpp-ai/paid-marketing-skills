# Waste Scoring Model

## Waste Categories

Every NEGATE term must be assigned exactly one waste category. Categories are mutually exclusive — pick the primary reason.

### 1. Irrelevant (highest confidence)
The term has zero relationship to the product/service. No interpretation makes it relevant.
- Examples: "CRM" campaign matching "car repair manual", pet food brand matching "dog training tips"
- Confidence: Always high. These are clear negations.
- Typical source: Broad match or phrase match overreach.

### 2. Expensive Non-Converter
The term is arguably relevant but has consumed significant spend without converting.
- Threshold: Spend ≥ 3x target CPA with 0 conversions AND ≥10 clicks (sufficient data)
- LTV adjustment: If the user provides LTV data, adjust threshold to 3x (Revenue per conversion × margin) instead of 3x target CPA. A £200 CPA looks wasteful against a £50 target, but if LTV is £5,000 with 40% margin, the effective threshold is 3x £2,000 = £6,000 spend before flagging.
- Conversion lag check: Before flagging, note that if the reporting window is shorter than the typical conversion cycle, these may convert later. Add caveat to output.

### 3. Off-Brand / Navigational Mismatch
The term is seeking a different brand or website.
- Own brand in generic campaign: Not waste — it's a campaign structure gap. Flag as negative keyword gap, not waste.
- Other brand navigational: Waste unless competitor bidding is intentional.
- Brand + generic compound for other brand ("Salesforce CRM pricing"): Waste unless intentional competitor targeting confirmed.

### 4. Competitor (Unintentional)
A competitor brand name triggering your ads when you haven't opted into competitor bidding.
- Check: Ask user if competitor bidding is intentional before classifying as waste.
- If intentional: Remove from waste calculation entirely — it's a strategic choice.
- If unintentional: Full cost is waste. Recommend exact negative on competitor brand name.

### 5. Intent Mismatch (adjusted waste)
The term has valid intent but is triggering the wrong campaign/funnel stage.
- This is NOT full waste — the click had value, just not in this campaign context.
- Count at 50% of actual cost in waste calculation (the other 50% would have been spent anyway if properly routed).
- Recommend reallocation, not negation.

## Waste Calculation

```
Total Identifiable Waste = 
  Σ (Irrelevant term costs × 100%)
  + Σ (Expensive non-converter costs × 100%)  
  + Σ (Off-brand/navigational costs × 100%)
  + Σ (Unintentional competitor costs × 100%)
  + Σ (Intent mismatch costs × 50%)

Estimated Recoverable Spend = Total Identifiable Waste × 0.90
(10% margin of error — some negatives may block edge-case relevant queries)
```

## Waste as Percentage
Always present waste as both absolute £/$ and as a percentage of total spend in the report period. Context matters — £500 waste in a £5,000 account is urgent (10%), £500 in a £500,000 account is noise (0.1%).

## LTV-Adjusted Waste

When the user provides margin or LTV data, recalculate "expensive non-converter" thresholds:

| Data provided | Adjusted threshold |
|---|---|
| Target CPA only | 3x target CPA, 0 conversions |
| Target CPA + average order value | 3x AOV, 0 conversions |
| Target CPA + LTV | 3x (LTV × margin), 0 conversions |
| Target CPA + LTV + margin | Most accurate: 3x (LTV × margin) |

If LTV data makes a previously "wasteful" term acceptable, reclassify from NEGATE to MONITOR with a note: "High CPA but within LTV-adjusted threshold. Monitor for 30 more days."
