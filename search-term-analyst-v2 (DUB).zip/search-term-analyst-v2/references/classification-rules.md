# Classification Rules

## Close Variant Grouping

Before classifying individual terms, group close variants into clusters.

**Grouping method:**
1. Normalise all terms to lowercase, strip punctuation
2. Stem or lemmatise (running → run, shoes → shoe)
3. Group terms that share the same root words regardless of order ("best crm software" and "software crm best" are the same cluster)
4. EXCEPTION: Do not cluster terms where word order changes intent ("buy insurance" vs "insurance buy-back", "return policy" vs "policy return")
5. Assess cluster-level metrics (sum impressions, clicks, cost, conversions) before classifying individual terms

**Why this matters:** Google's close variant matching means a single keyword can trigger dozens of variant search terms. A term with 1 click individually might belong to a cluster with 50 clicks and 5 conversions — that cluster is a strong ADD candidate, not a MONITOR.

## Classification Model

Assign every search term to exactly ONE primary category:

### ADD — Convert to keyword
Conditions (any of):
- Term has ≥2 conversions and CPA ≤ target CPA (or ≤ 1.5x target if LTV justifies)
- Term's close variant cluster has ≥3 conversions and cluster CPA ≤ target CPA
- Term has 1 conversion and CPA < 0.5x target CPA (high efficiency signal)
- Term is not already an exact match keyword in the triggering ad group

Match type recommendation flows from `match-type-logic.md`.

### NEGATE — Add as negative keyword
Conditions (any of):
- Term has ≥ 5x target CPA spend with 0 conversions (expensive non-converter)
- Term is clearly irrelevant to the product/service (intent mismatch)
- Term is a competitor brand and competitor bidding is NOT intentional
- Term is navigational for a different brand/site
- Term has ≥ 3x target CPA spend with 0 conversions AND ≥20 clicks (sufficient data)
- Term contains words from the known-irrelevant list (jobs, careers, DIY, free, salary, wiki, reddit — adjust per vertical)

NEVER negate a term that has conversions without explicit user confirmation, regardless of CPA.

### MONITOR — Insufficient data
Conditions:
- Term has < threshold impressions (default: 100, adjustable) AND < threshold clicks (default: 10)
- Term has 1 conversion but insufficient volume to assess reliability
- Term is ambiguous — could be relevant but needs more data

### CANNIBALISATION — Duplicate triggering
Conditions:
- Same search term (or close variant cluster) triggers ≥2 campaigns or ≥2 ad groups with DIFFERENT goals or bidding strategies
- Same term across ad groups in the SAME campaign with the SAME goal is NOT cannibalisation — this is normal auction behaviour
- Flag the location with the best CPA as the "winner" and recommend pausing or negating in other locations

### EMERGING — Early signals
Conditions:
- Term has 1-2 conversions with CPA ≤ target CPA
- Term has high CTR (>2x account average) with few impressions (<50)
- Term represents a new theme or angle not covered by existing keywords
- Close variant cluster shows growth trend (if date-range data allows comparison)

## Intent Tier Classification

Every search term gets an intent tier label. This is a secondary flag layered on top of the primary classification.

### Tier 1 — Transactional (bottom funnel)
Signals: buy, order, purchase, pricing, cost, discount, coupon, deal, cheap, best [product], [product] near me, [brand] + [product], subscribe, sign up, demo, trial, quote, hire
- These should appear in conversion-focused campaigns with aggressive bidding.

### Tier 2 — Commercial Investigation (mid funnel)
Signals: best, top, review, compare, vs, alternative, [product] for [use case], which [product], pros and cons, worth it, [product] 2024/2025/2026
- These belong in consideration campaigns. Acceptable CPA: 1.5-2x bottom-funnel target.

### Tier 3 — Informational (top funnel)
Signals: what is, how to, how does, guide, tutorial, definition, examples, meaning, types of, benefits of, [concept] explained
- These rarely belong in conversion campaigns. If triggering a conversion campaign, flag as INTENT MISMATCH. Recommend: move to awareness/content campaign with different bidding, or negate from conversion campaign.

### Tier 4 — Navigational (brand/site-seeking)
Signals: [brand name], [brand] login, [brand] support, [brand] phone number, [website].com
- If it's YOUR brand: should trigger brand campaign only. If triggering generic campaigns, that's a campaign-level negative gap.
- If it's ANOTHER brand: negate unless intentional competitor bidding.

### Intent Mismatch Flag
When a term's intent tier doesn't match the campaign's purpose:
- Tier 3 (informational) in a Tier 1 (conversion) campaign → Flag. Don't call it waste — call it a structure problem. Recommend reallocation.
- Tier 1 (transactional) in a Tier 3 (awareness) campaign → Flag as opportunity. The term should be in a conversion campaign.
- Tier 4 (navigational for own brand) in generic campaigns → Flag as negative keyword gap.

## Default Thresholds

These apply when the user doesn't provide overrides:

| Parameter | Default | Notes |
|---|---|---|
| Target CPA | Median CPA of converting terms | Calculated from the data |
| Minimum impressions for classification | 100 | Below this → MONITOR |
| Minimum clicks for non-converter flag | 10 | Below this → insufficient data |
| Expensive non-converter threshold | 3x target CPA spend, 0 conversions | Conservative — avoids false positives |
| Concentration warning: single term | >15% of total spend | Bid management issue |
| Concentration warning: top 5 terms | >50% of total spend | Portfolio risk |
| Close variant cluster minimum | 2 terms | Below this, assess individually |
