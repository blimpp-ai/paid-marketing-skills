# Google Ads Editor Export

## Purpose

After analysis, generate CSV files that a media buyer can import directly into Google Ads Editor. This turns a 30-minute manual implementation into a 2-minute upload.

## ADD Keywords Export

**Filename:** `add_keywords_[date].csv`

**Column structure (Google Ads Editor compatible):**

```
Campaign,Ad Group,Keyword,Match Type,Max CPC,Status
```

**Field rules:**
- **Campaign**: Exact campaign name from the search term report
- **Ad Group**: Exact ad group name from the report. If recommending a new ad group, note it in a comment column but use the existing ad group for import compatibility.
- **Keyword**: The search term, formatted for the match type:
  - Exact: `[keyword here]`
  - Phrase: `"keyword here"`
  - Broad: `keyword here` (no brackets or quotes)
- **Match Type**: `Exact`, `Phrase`, or `Broad` (capitalised, no abbreviations)
- **Max CPC**: Leave blank (let Smart Bidding handle) or set to the current average CPC for that ad group if manual bidding
- **Status**: `Enabled`

**Example output:**
```csv
Campaign,Ad Group,Keyword,Match Type,Max CPC,Status
Brand - UK,Brand Core,[acme crm pricing],Exact,,Enabled
Generic - CRM,CRM Features,"crm for small business",Phrase,,Enabled
Generic - CRM,CRM Comparison,best crm software,Broad,,Enabled
```

## NEGATE Keywords Export

**Filename:** `negate_keywords_[date].csv`

**Column structure (Google Ads Editor compatible):**

For campaign-level negatives:
```
Campaign,Keyword,Match Type
```

For ad group-level negatives:
```
Campaign,Ad Group,Keyword,Match Type
```

For shared negative lists (account level):
```
Shared Set,Keyword,Match Type
```

**Field rules:**
- **Keyword**: The term to negate, formatted for the negative match type:
  - Exact negative: `[keyword here]`
  - Phrase negative: `"keyword here"`
  - Broad negative: `keyword here`
- **Match Type**: `Exact`, `Phrase`, or `Broad`
- **Shared Set**: Name of the shared negative list (e.g., "Global Negatives", "Competitor Brands")

**Example output:**
```csv
Campaign,Keyword,Match Type
Generic - CRM,"crm jobs",Phrase
Generic - CRM,[salesforce login],Exact
Generic - CRM,salary,Broad
```

## Presentation to User

After generating the markdown analysis output:

1. State: "I can generate Google Ads Editor-ready CSV files for the ADD and NEGATE actions. Want me to create those?"
2. If yes, generate both CSVs
3. Save to `/mnt/user-data/outputs/` with descriptive filenames
4. Note any terms where the recommendation is CONDITIONAL (e.g., "negate unless competitor bidding is intentional") — these should be reviewed before importing

## Edge Cases

- If a term is recommended for ADD in one campaign and NEGATE in another (cannibalisation resolution), create separate rows in both files with a comment noting the relationship.
- If campaign or ad group names contain commas, wrap in double quotes in the CSV.
- If the user's report doesn't include campaign/ad group columns, the CSVs can't be generated — note this and offer the keyword lists without campaign mapping instead.
