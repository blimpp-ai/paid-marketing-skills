# Business Context Integration

## Why Context Matters

A search term report without business context produces generic recommendations. With context, the same data produces decisions that account for unit economics, funnel structure, and strategic intent.

## Context Collection Framework

This is Step 1 — it runs BEFORE any data parsing or analysis. If the user provides a search term report without context, stop and ask. Do not proceed to analysis until context is collected or the user explicitly declines to provide it.

### Required Context (ask explicitly if not provided)

**Target CPA or Target ROAS**
- What it shapes: The threshold for "expensive non-converter" and "efficient ADD candidate"
- Default if not provided: Median CPA of all converting terms in the dataset
- Ask: "What's your target CPA or ROAS for this campaign/account?"

**Brand terms**
- What it shapes: Whether branded queries are flagged as cannibalisation or treated as expected
- Default if not provided: Attempt to infer from the highest-CTR, lowest-CPA terms (these are usually branded)
- Ask: "What's your brand name and any product names I should treat as branded?"

**Intentional competitor targeting**
- What it shapes: Whether competitor brand terms are flagged as waste
- Default if not provided: Assume NOT intentional — flag all competitor terms as waste
- Ask: "Do you intentionally bid on any competitor brand names?"

### Valuable Context (ask if the user seems engaged, otherwise use defaults)

**Funnel structure / campaign purpose mapping**
- What it shapes: Intent tier mismatch analysis
- Default if not provided: Infer from campaign names (campaigns containing "brand", "generic", "competitor", "awareness", "retargeting" are usually labelled meaningfully)
- Ideal: User provides a simple mapping like "Campaign A = bottom funnel, Campaign B = mid funnel"
- Ask: "Can you tell me which campaigns are bottom-funnel (conversion) vs mid/top funnel?"

**Product margins or LTV**
- What it shapes: Whether high-CPA terms are truly wasteful or acceptable given lifetime value
- Default if not provided: Ignore LTV adjustment — use raw CPA targets
- Ideal: "Our average LTV is £X with Y% margin" or "Our average order value is £X with Y% margin"
- Ask only if you see terms with high CPA that are clearly relevant to the product: "Some terms have a high CPA but look genuinely relevant. Do you have LTV or margin data that might justify a higher CPA threshold?"

**Conversion window / attribution model**
- What it shapes: Whether "0 conversion" terms might convert later
- Default: Add caveat to expensive non-converters about conversion lag
- Ideal: "We use 30-day click attribution" or "Our sales cycle is 90 days"
- Ask only if you see many high-spend 0-conversion terms that look relevant: "What's your typical conversion window? Some terms look relevant but show no conversions — they might convert later."

### Nice-to-Have Context (don't ask, but use if volunteered)

**Seasonality awareness**: "We're in peak season" or "This is off-season data" — adjusts how aggressively to negate low-performers.

**Geographic targeting**: If the account targets specific regions, local intent modifiers are more/less relevant.

**New vs established account**: New accounts need more MONITOR patience; established accounts can be more aggressive with negations.

## How Context Flows Into Classification

| Context field | Classification impact |
|---|---|
| Target CPA | Sets NEGATE threshold (3x), ADD threshold (≤1x), commercial investigation tolerance (1.5-2x) |
| Brand terms | Prevents brand queries being flagged as cannibalisation in generic campaigns — reclassifies as negative keyword gap |
| Competitor intent | Flips competitor terms from WASTE to STRATEGIC (excluded from waste calc) |
| Funnel mapping | Enables intent mismatch detection — the highest-value secondary flag |
| LTV / margins | Adjusts "expensive non-converter" threshold, potentially saving terms from negation |
| Conversion window | Adds caveats to NEGATE recommendations for relevant-looking zero-converters |

## Handling Missing Context Gracefully

If the user provides the report without any context and says "just analyse it":
1. Calculate target CPA from the data (median of converting terms)
2. Infer brand terms from high-CTR/low-CPA terms
3. Assume no intentional competitor bidding
4. Infer funnel from campaign names where possible
5. Skip LTV adjustment
6. Add a "Context assumptions" section at the top of the output listing what was inferred
7. Note: "These results would be more precise with target CPA, brand terms, and funnel mapping. Let me know if you'd like to refine."
