# Match Type Logic

## For ADD Terms (Positive Keywords)

### Exact Match — Use when:
- Term is ≤3 words AND has clear, unambiguous purchase intent
- Term already converts well — you want to lock in this specific query
- Term is a branded compound ("Acme CRM pricing") where you want precise control
- Term is high-volume (>500 impressions/month) — exact match prevents budget bleed to variants
- Term has a CPA significantly below target — capture this efficiency

### Phrase Match — Use when:
- Term is 3-5 words with a core phrase that carries the intent ("best CRM for startups")
- You want to capture useful modifiers the user might add (location, size, feature)
- Term converts but you expect valuable longer-tail variants exist
- The key intent-carrying phrase is 2-3 words within a longer query

### Broad Match — Use when:
- Term represents a theme you want to explore (use with Smart Bidding only)
- You have sufficient conversion data for the algorithm to optimise (>30 conversions/month in the campaign)
- Adding alongside exact match as a "discovery" keyword with lower bids
- NEVER recommend broad match without Smart Bidding — flag this explicitly

### Decision Tree
```
Is the term ≤3 words with clear intent?
  YES → Exact match
  NO → Is there a 2-3 word core phrase carrying the intent?
    YES → Phrase match (using the core phrase)
    NO → Is Smart Bidding active with >30 conv/month?
      YES → Broad match (with monitoring note)
      NO → Phrase match (safest default)
```

## For NEGATE Terms (Negative Keywords)

### Exact Negative — Use when:
- The specific term is irrelevant but close variants might be valuable
- Example: Negate "CRM free trial" (competitor's offer) but keep "CRM trial" (generic intent)
- The term is a competitor brand name — exact prevents blocking useful compound queries

### Phrase Negative — Use when:
- Any query containing this phrase is irrelevant
- Example: Negate "jobs in" as phrase — blocks "CRM jobs in London", "sales jobs in Manchester"
- The irrelevant signal is in a multi-word modifier, not the head term

### Broad Negative — Use when:
- The individual WORD is irrelevant regardless of context
- Example: Negate "salary" as broad — any query containing "salary" is off-topic for a SaaS product
- USE WITH CAUTION: broad negatives block more than expected. Only for clearly irrelevant single words.
- NEVER broad-negate a word that could appear in a relevant query. When in doubt, use phrase.

### Negation Level
- **Campaign level**: The term is irrelevant to the entire campaign's product/service
- **Ad group level**: The term is relevant to the campaign but belongs in a different ad group
- **Account level (shared list)**: The term is irrelevant across all campaigns (e.g., "jobs", "salary", "wiki")

Always specify the recommended level. Default to campaign level unless there's a clear reason for ad group or account level.

### Negative Decision Tree
```
Is a single word the irrelevant signal?
  YES → Could that word ever appear in a relevant query?
    YES → Phrase negative (include surrounding context)
    NO → Broad negative (the word itself is toxic)
  NO → Is the exact multi-word phrase the problem?
    YES → Is there a close variant you'd want to keep?
      YES → Exact negative
      NO → Phrase negative
    NO → Break down which part is irrelevant and negate that part
```
