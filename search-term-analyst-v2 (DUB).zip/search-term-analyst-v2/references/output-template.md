# Output Template

## Structure

Generate the action plan in this exact structure. Every section is mandatory even if empty (state "None identified" if a category has zero terms).

```markdown
## SEARCH TERM ANALYSIS — [date range if known]

**Context assumptions:** [List any inferred context: calculated target CPA, inferred brand terms, assumed funnel mapping. Omit if user provided all context explicitly.]

**Summary:** [Total terms analysed] terms | [Total spend] spend | [Total waste] identifiable waste ([waste %]) | [ADD count] terms to add | [NEGATE count] terms to negate

---

### 1. ADD AS KEYWORDS ([count] terms)

| Search Term | Variant Cluster | Rec. Match | Campaign / Ad Group | Clicks | Conv | CPA | Rationale |
|---|---|---|---|---|---|---|---|

**Priority adds (implement first):**
1. [Term] → [match type] in [campaign/ad group] — [reason, e.g., "12 conversions at £18 CPA vs £45 target"]
2. ...
3. ...

---

### 2. NEGATE ([count] terms, [total cost] waste)

| Search Term | Neg. Match Type | Level | Campaign / Ad Group | Cost | Clicks | Conv | Waste Category |
|---|---|---|---|---|---|---|---|

**Priority negations (highest spend first):**
1. [Term] → [neg match type] at [level] — [cost] wasted, [category]
2. ...
3. ...

---

### 3. CANNIBALISATION FLAGS ([count] terms)

| Search Term | Campaigns Triggered | Ad Groups | Total Cost | Best CPA Location | Recommended Action |
|---|---|---|---|---|---|

For each flag, recommend ONE of:
- Negate in all locations except the best performer
- Consolidate into a single ad group
- Accept if campaigns serve different funnel stages (and note this)

---

### 4. INTENT TIER MISMATCHES ([count] terms)

| Search Term | Intent Tier | Campaign Purpose | Mismatch Type | Cost | Recommended Action |
|---|---|---|---|---|---|

Mismatch types:
- "Informational query in conversion campaign" → Recommend negate from conversion campaign, optionally add to awareness campaign
- "Transactional query in awareness campaign" → Recommend add to conversion campaign
- "Own-brand in generic campaign" → Recommend campaign-level brand negative

---

### 5. CONCENTRATION WARNINGS ([count] terms)

| Search Term | Spend | % of Total | Conversions | CPA | Risk |
|---|---|---|---|---|---|

For each warning:
- If the term is converting efficiently: "High concentration but performing. Monitor for diminishing returns. Consider bid caps."
- If the term is converting inefficiently: "High concentration AND underperforming. Reduce bids or pause."
- If the term is a brand term: "Expected concentration. Ensure brand campaign has appropriate budget allocation."

---

### 6. EMERGING OPPORTUNITIES ([count] terms)

| Search Term | Impressions | Clicks | Conv | CTR | Signals | Recommended Action |
|---|---|---|---|---|---|---|

Signals column: note what makes this term interesting (high CTR, early conversions, new theme, growing volume, underserved by current keywords).

---

### 7. WASTE SUMMARY

**Total identifiable waste: [£X] ([Y%] of total spend)**
**Estimated recoverable spend: [£X] (after 10% margin of error)**

Breakdown:
- Irrelevant terms: [£X] ([count] terms)
- Expensive non-converters: [£X] ([count] terms)
- Off-brand / navigational: [£X] ([count] terms)
- Competitor terms (unintentional): [£X] ([count] terms)
- Intent mismatches (50% attribution): [£X] ([count] terms)

---

### PRIORITY ACTIONS (Top 10)

[Numbered 1-10, ranked by estimated £/$ impact — highest first]

Each action must be specific and executable:
- ✅ "Negate 'crm jobs' as phrase negative in Generic - CRM campaign — saves £342/month"
- ✅ "Add [best crm for startups] as exact match in Generic - CRM / CRM Comparison — 8 conversions at £22 CPA"
- ❌ "Review high-CPA terms" (too vague)
- ❌ "Consider adding some converting terms" (not specific)

---

### GOOGLE ADS EDITOR EXPORT

[Offer to generate importable CSVs for ADD and NEGATE actions — see `references/google-ads-editor-export.md`]
```

## Formatting Rules

- Use the user's currency symbol (infer from the data, or ask)
- Round CPA/ROAS to 2 decimal places
- Show percentages to 1 decimal place
- For large datasets (500+ terms), show top 20-30 per category with a note: "[X] additional terms in this category — export CSV for full list"
- Bold the single most impactful finding in each section
