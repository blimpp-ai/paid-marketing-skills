# Search Term Analyst

Senior paid search specialist skill for analysing Google Ads search term reports and producing actionable, prioritised media buying decisions.

## What it does

Takes a Google Ads search term export (CSV, XLSX, or pasted table) and produces:
- 7-section action plan: Add, Negate, Cannibalisation, Intent Mismatches, Concentration Warnings, Emerging, Waste Summary
- Top-10 priority actions ranked by financial impact
- Google Ads Editor-ready CSV exports for immediate implementation
- LTV/margin-adjusted waste calculations when business context is provided

## Files

```
search-term-analyst/
├── SKILL.md                              # Process document (~195 lines)
├── README.md                             # This file
└── references/
    ├── classification-rules.md           # Classification model, intent tiers, close variants, thresholds
    ├── match-type-logic.md               # Match type decision trees for ADD and NEGATE terms
    ├── waste-scoring.md                  # Waste categories, LTV-adjusted scoring, calculation model
    ├── business-context.md               # Context collection framework, defaults, inference rules
    ├── google-ads-editor-export.md       # CSV export formats for Google Ads Editor import
    └── output-template.md                # 7-section output structure with formatting rules
```

## Key improvements over v1

- **Intent tier analysis**: Flags informational queries in conversion campaigns as structure problems, not waste
- **Close variant clustering**: Groups variant terms and assesses clusters before classifying individuals
- **Concentration risk detection**: Warns when spend is over-concentrated on a few terms
- **LTV-adjusted waste scoring**: Adjusts "expensive non-converter" thresholds when margin/LTV data is provided
- **Google Ads Editor export**: Generates import-ready CSVs so actions can be implemented in minutes
- **Business context integration**: Collects target CPA, brand terms, funnel structure, competitor intent before classifying
- **Pre-seeded learnings**: 10 rules and 5 failure modes from production PPC experience
